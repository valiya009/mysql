const mysql = require('mysql')
const con = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"chandresh"
});

con.connect((err)=>{
    if(err)
    {
        console.warn('not connected')
    }
    else
    {
        console.warn('connected')
    }
});