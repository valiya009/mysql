const mysql = require('mysql');
const con = mysql.createConnection({
    host: "localhost",
    user:"root",
    password :"",
    database:"chandresh"
});

con.connect((err)=>{
    if(err)
    {
        console.warn('data base not connected');
    }
    else
    {
        console.warn("dtabase connected")
    }
});
module.exports = con;