const express = require('express');
const con = require("./config")
const app = express()

app.get("/",(req,res)=>{
    con.query("select * from student",(err,result)=>{
        if(err)
        {
            res.send("error in api")
        }
        else
        {
            res.send(result)
        }
    });
});

app.post("/",(req,res)=>{
    const data  = req.body;
    con.query("INSERT INTO student SET?",data,(err,result,fields)=>{
        if(err)
            {
                res.send("error in api")
            }
            else
            {
                res.send(result)
            }
    });
});

app.put("/",(req,res)=>{
    const data = [req.body.name,req.body.age,req.params.id]
    con.query("UPDATE student SET student_name=?,student_age=?,WHERE id=?",data,(err,result,fields)=>{
        if(err)
            {
                res.send("error in api")
            }
            else
            {
                res.send(result)
            }
    });
});
app.delete("/",(req,res)=>{
    const data = [req.params.id]
    con.query("DEKLETE FROM student WHERE id = ?",data,(err,result,fields)=>{
        if(err)
            {
                res.send("error in api")
            }
            else
            {
                res.send(result)
            }
    });
});

app.listen(5000);